package com.dafttech.terra.game.world.environment;

import com.dafttech.terra.game.world.World;

public class WeatherSunny extends Weather {
    @Override
    public void update(World world, float delta) {
        // TODO Auto-generated method stub

    }

    @Override
    public float getWindSpeed(World world) {
        return 0;
    }
}
