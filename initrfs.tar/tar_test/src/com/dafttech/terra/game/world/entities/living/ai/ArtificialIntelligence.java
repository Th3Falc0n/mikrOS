package com.dafttech.terra.game.world.entities.living.ai;

import com.dafttech.terra.game.world.entities.models.EntityLivingAI;

public class ArtificialIntelligence {
    EntityLivingAI assignedEntity;

    public void setEntity(EntityLivingAI entityLivingAI) {
        assignedEntity = entityLivingAI;
    }

    public void update(float delta) {

    }
}
