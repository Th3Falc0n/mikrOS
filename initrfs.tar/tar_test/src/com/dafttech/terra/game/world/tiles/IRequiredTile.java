package com.dafttech.terra.game.world.tiles;

public interface IRequiredTile {
    public Tile getRequiredTile();
}
