package com.dafttech.terra.resources;

public class Options {
    public static final int BLOCK_SIZE = 16;
}
