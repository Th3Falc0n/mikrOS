package com.dafttech.terra.engine.input.handlers;

public interface IStringInputHandler {
    public void handleInput(String str);
}
