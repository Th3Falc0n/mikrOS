package com.dafttech.terra.engine.input;

public interface IFocusableTyping {
    public void onKeyTyped(char c);

    public void onKeyDown(int i);
}
