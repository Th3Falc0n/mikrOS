package com.dafttech.terra.engine.lighting;

public interface ILightEmitter {
    public PointLight getEmitter();
}
