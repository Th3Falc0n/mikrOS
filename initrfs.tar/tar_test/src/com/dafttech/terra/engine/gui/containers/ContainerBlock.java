package com.dafttech.terra.engine.gui.containers;

import com.dafttech.terra.engine.Vector2;

public class ContainerBlock extends GUIContainer {
    public ContainerBlock(Vector2 p, Vector2 s) {
        super(p, s);
    }
}
