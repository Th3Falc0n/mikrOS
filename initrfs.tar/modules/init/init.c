#include "stdint.h"
#include "stdio.h"
#include "vmmcall.h"
#include "process.h"
 
int main(void)
{
    printf("[INIT] Init process started... :) Thats so good!\n");


    return 0;
}
